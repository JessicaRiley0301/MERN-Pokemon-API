
import './App.css';
import React, {useState} from 'react';

function App() {
  const [pokemon, setPokemon] = useState([]);

  //fetch method
  const fetchPokemons = () => {
    fetch("https://pokeapi.co/api/v2/pokemon?offset=0&limit=807")
    .then(response => response.json())
    .then(response => {
      console.log(response.results)
      setPokemon(response.results)
    }) 
    .catch(err => {
        console.log(err);
    })
    
  }

  return (

    <div className="App">
      <h1>Pokemon Api</h1>
      <button onClick={fetchPokemons}>Fetch Pokemon</button>
      <hr/>
      {pokemon.map((pokemon,i) => 
        <ul>
          <li key={i}>{pokemon.name}</li>
        </ul>
        )
      }
    </div>
  );
}

export default App;
